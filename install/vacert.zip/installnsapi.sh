#!/bin/sh

BCKEXT=`date +%Y%m%d`
CURRDIR=`pwd`
VCDIST="vacert.tar"

#
# First, make sure that the install tar file exists.
#
if [ ! -f "$VCDIST" ]
then
	echo $VCDIST distribution file not found. Exiting.
	exit 1
fi

#
# Prompt the user for the location of the directory that contains the
# server instance directories.
#
echo Enter the full pathname of the directory that contains the server
echo instance where you will install the ValiCert Web Server Validator.
read NSHOME

#
# Removes trailing '/' from NSHOME.
#
NSHOME=`echo $NSHOME | sed -e 's!/$!!'`

#
# Check that the specified directory exists. If not, exit.
#
if [ ! -d "$NSHOME" ]
then
	echo $NSHOME could not be found. Exiting.
	exit 1
fi

#
# Setup the server specific config directory
# By default this might be https-$HOSTNAME but
# is user configurable.
#
SRVDIR=$NSHOME
SERVERS=`cd $NSHOME; ls -d https-*`
NUM=`echo $SERVERS | wc -w`
if [ $NUM -gt 1 ]
then
	echo
	echo
	echo "The following secure Enterprise Servers have been found on your system:"
	echo
	for aserver in $SERVERS
	do
		echo $aserver
	done
	echo
	DEFAULT_SRV=`echo $SERVERS | cut -d' ' -f1`
	echo "Please select which one to configure [$DEFAULT_SRV]?"
	read SERVER
	if [ "$SERVER" = "" ]
	then
		SERVER=$DEFAULT_SRV
	fi
	echo
	SRVDIR=$SRVDIR/$SERVER
else
	SRVDIR=$SRVDIR/$SERVERS
fi

echo
echo "Installing for $SRVDIR..."
echo
if [ ! -d "$SRVDIR" ]
then
	echo Could not access $SRVDIR. Exiting.
	exit 1
fi

NSCONFDIR=$SRVDIR/config
VCCONFDIR=$NSCONFDIR/vacert

#
# Make sure we can write to the docs directory--and that it exists.
#
NSDOCDIR=`egrep docroot $NSCONFDIR/server.xml | sed -e "s/<PROPERTY name=\"docroot\" value=\"//;s/\"\/>//;s/ *//" | sort -u`
#NSDOCDIR=$NSHOME/docs
if [ -d "$NSDOCDIR" ]
then
	touch $NSDOCDIR/writetest 2>/dev/null
	if [ $? -gt 0 ]
	then
		echo Could not write to $NSDOCDIR. Exiting.
		exit 1
	else
		rm -f $NSDOCDIR/writetest
		VCDOCDIR=$NSDOCDIR/vacert-errors
	fi
else
	echo $NSDOCDIR could not be found. Exiting.
	exit 1
fi

#
# Make sure the obj.conf file exists in the config directory and make
# sure that the user can write to the confg directory as well. Back up
# obj.conf when we're done.
#
if [ -f $NSCONFDIR/obj.conf ]
then
	touch $NSCONFDIR/writetest 2>/dev/null
	if [ $? -gt 0 ]
	then
		echo Could not write to $NSCONFDIR. Exiting.
		exit 1
	else
		rm -f $NSCONFDIR/writetest
		cp $NSCONFDIR/obj.conf $NSCONFDIR/obj.conf.$BCKEXT
	fi
else
	echo $NSCONFDIR/obj.conf file not found. Exiting.
	exit 1
fi

if [ -f $NSCONFDIR/magnus.conf ]
then
	touch $NSCONFDIR/writetest 2>/dev/null
	if [ $? -gt 0 ]
	then
		echo Could not write to $NSCONFDIR. Exiting.
		exit 1
	else
		rm -f $NSCONFDIR/writetest
		cp $NSCONFDIR/magnus.conf $NSCONFDIR/magnus.conf.$BCKEXT
	fi
else
	echo $NSCONFDIR/magnus.conf file not found. Exiting.
	exit 1
fi

#
# Make sure the install files exist in the current directory.
#
if [ ! -f "$VCDIST" ]
then
	echo vcnsapi distribution not found in current directory. Exiting.
	exit 1
fi


# Extract files from the distribution file. Assuming that we've already
# uncompressed (or used gunzip) to get the installer and tar file. Should
# check if CURRDIR is really necessary. It may not be.
#
#( cd $SRVDIR; tar -xvof $CURRDIR/$VCDIST )

( cd $NSCONFDIR; tar -xvof $CURRDIR/$VCDIST vacert)
( cd $NSDOCDIR; tar -xvof $CURRDIR/$VCDIST vacert-errors)
( cd $SRVDIR )

#
# Edit magnus.conf
#
# First, see if there are already ValiCert-related entries in obj.conf.
# If not, then add them to the top of the file. Check one-by-one.
#

echo
echo "Customizing server configuration file $NSCONFDIR/magnus.conf..."
echo

egrep -i -s -e Init.*va_ocsp_auth $NSCONFDIR/magnus.conf
if [ $? -eq 1 ]
then
	sed -e "\$a\\
Init fn=\"load-modules\" funcs=\"va_nsapi_init,va_ocsp_auth\" shlib=\"$VCCONFDIR/ocsp.so\"" $NSCONFDIR/magnus.conf > /tmp/magnus.conf.tmp
	mv -f /tmp/magnus.conf.tmp $NSCONFDIR/magnus.conf 
fi


egrep -i -s -e Init.*va-config-file $NSCONFDIR/magnus.conf
if [ $? -eq 1 ]
then
	sed -e "\$a\\
Init fn=\"va_nsapi_init\", va-config-file=\"$VCCONFDIR/vacert.ini\"" $NSCONFDIR/magnus.conf > /tmp/magnus.conf.tmp
	mv -f /tmp/magnus.conf.tmp $NSCONFDIR/magnus.conf
fi

#
# Edit obj.conf
#
# First, see if there are already ValiCert-related entries in obj.conf.
# If not, then add them to the top of the file. Check one-by-one.
#

echo
echo "Customizing server configuration file $NSCONFDIR/obj.conf..."
echo

#
# After the "document-root" value has been set, add an entry for valicert
# docs--but only if the valicert value has not been set.
#
egrep -i -s -e $VCDOCDIR $NSCONFDIR/obj.conf
if [ $? -eq 1 ]
then
	sed -e "/^NameTrans.*document-root/a\\
NameTrans fn=\"pfx2dir\" from=\"/vacert-errors\" dir=\"$VCDOCDIR\""  $NSCONFDIR/obj.conf > /tmp/obj.conf.tmp
	mv -f /tmp/obj.conf.tmp $NSCONFDIR/obj.conf
fi

#
# Now, in the "default" object description, add the test_auth
# entry, if it doesn't already exist.
#
# First try with default in no quotes
#
egrep -s -i -e "PathCheck +fn=.*va_ocsp_auth" $NSCONFDIR/obj.conf
if [ $? -eq 1 ]
then
	sedString="PathCheck fn=\"va_ocsp_auth\""
	sed -e "/^<Object name=default/a\\
$sedString" $NSCONFDIR/obj.conf > /tmp/obj.conf.tmp
	mv -f /tmp/obj.conf.tmp $NSCONFDIR/obj.conf
fi

#
# Next try with default in quotes.
#
egrep -s -i -e "PathCheck +fn=.*va_ocsp_auth" $NSCONFDIR/obj.conf
if [ $? -eq 1 ]
then
	sedString="PathCheck fn=\"va_ocsp_auth\""
	sed -e "/^<Object name=\"default\"/a\\
$sedString" $NSCONFDIR/obj.conf > /tmp/obj.conf.tmp
	mv -f /tmp/obj.conf.tmp $NSCONFDIR/obj.conf
fi

#
# Edit the vcnsapi.ini file
#
# Replace the template file
#
TEMPF=/tmp/vacert.ini.$$
INIF=$VCCONFDIR/vacert.ini

echo
echo "Customizing initialization file $INIF..."
echo

SED_STR=VA_TRUSTED_CAS
#sed -e "s!^#$SED_STR.*\$!$SED_STR=$VCCONFDIR\/issuers\/!" $INIF > $TEMPF
sed -e "s|$SED_STR=.*|$SED_STR=$VCCONFDIR\/issuers\/|" $INIF > $TEMPF
mv -f $TEMPF $INIF

SED_STR=VA_OCSPD_CERT
#sed -e "s!^#$SED_STR.*\$!$SED_STR=$VCCONFDIR\/certs\/ocsp\.crt!" $INIF > $TEMPF
sed -e "s|$SED_STR=.*|$SED_STR=$VCCONFDIR\/certs\/ocsp\.crt|" $INIF > $TEMPF
mv -f $TEMPF $INIF

SED_STR=VA_ERROR_DOCROOT
#sed -e "s!^#$SED_STR.*\$!$SED_STR=$VCDOCDIR-xxx\/!" $INIF > $TEMPF
sed -e "s|$SED_STR=.*|$SED_STR=$VCDOCDIR\/|" $INIF > $TEMPF
mv -f $TEMPF $INIF


#
# Create the uninstall file
#

VCUNINST=$VCCONFDIR/uninst.sh

if [ -f "$VCUNINST" ]
then
	rm -f "$VCUNINST"
fi

cat > $VCUNINST << EOF
#!/bin/sh
# ValiCert Web Server Validator Uninstall script
#
echo
echo "Deleting ValiCert Web Server Validator Files."
echo "Enter "y" to confirm; any other key to exit: "
echo
read CONFIRM
if [ "\$CONFIRM" != "y" ]
then
        echo "Installation aborted by user. Exiting."
        exit
fi

echo "Removing application files."
`tar -tf $VCDIST | egrep -ive "/$" | egrep -ive "docs" | sed -e "s!^!rm -f $SRVDIR/!"`
echo
echo
echo "Do you want do delete the ValiCert Web Server Validator Documentation?"
echo "Enter "y" to delete documentation; any other key to continue uninstall."
echo "Do not delete if the docs are shared by other server instances."
echo
echo
read CONFIRM
if [ "\$CONFIRM" = "y" ]
then
	`egrep -ie "^NameTrans.*\/vacert" $NSCONFDIR/obj.conf | sed -e "s!^.*dir=!rm -rf !"`
fi
mv -f $NSCONFDIR/magnus.conf $NSCONFDIR/magnus.conf.vc
mv -f $NSCONFDIR/obj.conf $NSCONFDIR/obj.conf.vc

echo "Removing ValiCert entries from magnus.conf."
sed -e "/vacert/d
		/va_nsapi_init/d
        /va_ocsp_auth/d" $NSCONFDIR/obj.conf.vc > $NSCONFDIR/magnus.conf
echo

echo "Removing ValiCert entries from obj.conf."
sed -e "/vacert/d
        /va_ocsp_auth/d" $NSCONFDIR/obj.conf.vc > $NSCONFDIR/obj.conf
echo
echo "Be sure to remove this file (uninst.sh) after you have uninstalled."
echo
EOF

chmod 755 $VCUNINST
echo
echo "Created uninstall script [$VCUNINST]."
echo
